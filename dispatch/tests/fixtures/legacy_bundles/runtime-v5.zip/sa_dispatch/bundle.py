"""Portable settled-ledger v5 bundles, with lossless audit rows and inert schedules.

Frozen v1-v4 layouts remain readable. Host device registrations are explicitly excluded from
portable bundles. Full in-process snapshots include them. Pending reservations
and nonterminal tasks are rejected rather than discarded or replayed on import.
"""
from contextlib import closing
import json
import re
from pathlib import Path
import sqlite3
import tempfile

from .artifacts import ArtifactError, ArtifactStore
from .canonical import sha256_ref
from .executor import receipt_bytes
from .models import DispatchError


V1_TABLES = {"tasks": "rowid", "leases": "task_id,fence", "events": "seq",
             "evidence": "evidence_id", "late_results": "id"}
V2_TABLES = {**V1_TABLES, "component_capabilities": "component,capability",
          "reconciliations": "rowid", "schedules": "id",
          "schedule_firings": "scheduled_at,fire_key", "schedule_events": "seq",
          "unified_events": "seq", "transport_handoffs": "task_id",
          "transport_artifact_grants": "grant_id", "schema_migrations": "version"}
V3_TABLES = {**V2_TABLES, "control_budgets": "budget_id", "control_approvals": "approval_id",
          "control_task_rules": "task_id", "control_reservations": "task_id,fence",
          "control_handoffs": "handoff_id", "control_events": "seq",
          "host_attempts": "task_id,fence", "host_events": "task_id,fence,seq"}
V4_TABLES = {**V3_TABLES, "claude_attempts":"task_id,fence"}
TABLES = dict(V4_TABLES)  # v5 adds schedules.max_slots, not another table.
SNAPSHOT_TABLES = {**TABLES, "devices": "device_id"}
V1_FORMAT = "sa_dispatch.bundle.v1"
V2_FORMAT = "sa_dispatch.bundle.v2"
V3_FORMAT = "sa_dispatch.bundle.v3"
V4_FORMAT = "sa_dispatch.bundle.v4"
FORMAT = "sa_dispatch.bundle.v5"
TERMINAL = {"succeeded", "no_new", "failed", "cancelled"}


def _present(conn):
    return {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
            if not r[0].startswith("sqlite_")}


def _unknown_populated(conn):
    for name in sorted(_present(conn) - set(SNAPSHOT_TABLES)):
        quoted = '"' + name.replace('"', '""') + '"'
        if conn.execute("SELECT 1 FROM " + quoted + " LIMIT 1").fetchone():
            return name
    return None


def snapshot_records(conn, *, include_devices=True):
    """Read all known tables in the caller's transaction; absent opt-ins are [].

    Unknown populated tables fail closed instead of silently losing new data.
    Reading a live snapshot is allowed; migration eligibility is checked later.
    """
    unknown = _unknown_populated(conn)
    if unknown:
        raise DispatchError("snapshot does not support populated table: " + unknown)
    present = _present(conn)
    tables = SNAPSHOT_TABLES if include_devices else TABLES
    return {table: [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY {order}")]
            if table in present else [] for table, order in tables.items()}


def ledger(path):
    with closing(sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)) as conn:
        conn.row_factory = sqlite3.Row
        conn.execute("BEGIN")
        try:
            return snapshot_records(conn, include_devices=False)
        except DispatchError as exc:
            raise ArtifactError("E_EXPORT_BLOCKED", str(exc)) from exc


def _settled(records):
    tasks = {row["task_id"]: row for row in records["tasks"]}
    if any(row["status"] not in TERMINAL for row in tasks.values()):
        raise DispatchError("settle queued, leased or unknown tasks before exporting")
    if any(row["state"] == "active" for row in records["leases"]):
        raise DispatchError("active leases cannot migrate")
    for table in ("leases", "events", "evidence", "late_results", "reconciliations",
                  "transport_handoffs", "transport_artifact_grants"):
        if any(row["task_id"] not in tasks for row in records.get(table, [])):
            raise DispatchError("orphan task reference in " + table)
    schedules = {row["id"] for row in records.get("schedules", [])}
    for row in records.get("schedules", []):
        if row["enabled"] not in (0, 1):
            raise DispatchError("invalid schedule enabled state")
        bound=row.get('max_slots')
        if bound is not None:
            if type(bound) is not int or not 1<=bound<=100000:
                raise DispatchError('invalid schedule lifetime slot bound')
            used=sum(f['schedule_id']==row['id'] for f in records.get('schedule_firings',[]))
            if used>bound or (used==bound and row['enabled']):
                raise DispatchError('schedule slot bound or exhaustion state disagrees with history')
    for row in records.get("schedule_firings", []):
        outcome = row.get("outcome", "created" if row.get("task_id") else "pending")
        if outcome == "pending":
            raise DispatchError("pending schedule reservations must be settled before migration")
        if outcome not in {"created", "skipped_catchup", "rejected"}:
            raise DispatchError("unknown schedule firing outcome cannot migrate")
        if row["schedule_id"] not in schedules:
            raise DispatchError("orphan schedule firing")
        if outcome == "created" and row.get("task_id") not in tasks:
            raise DispatchError("created firing requires a terminal task")
        if row.get("task_id") is not None and row["task_id"] not in tasks:
            raise DispatchError("orphan firing task")
    for row in records.get("unified_events", []):
        if row.get("source") == "dispatch" and row.get("task_id") is not None and row["task_id"] not in tasks:
            raise DispatchError("orphan dispatch projection task")
    if any(r['state'] != 'settled' for r in records.get('control_reservations', [])):
        raise DispatchError('unsettled budget reservations cannot migrate')
    if any(r['reserved_units'] != 0 for r in records.get('control_budgets', [])):
        raise DispatchError('held budget units cannot migrate')
    if any(r['state'] in ('offered','accepted') for r in records.get('control_handoffs', [])):
        raise DispatchError('active handoffs cannot migrate')
    if any(r['phase'] not in ('completed','failed','cancelled','interrupted','orphan_terminal','orphan_cancelled','not_started') for r in records.get('host_attempts', [])):
        raise DispatchError('unsettled host attempts cannot migrate')
    for row in records.get('claude_attempts',[]):
        if row['phase'] not in ('succeeded','failed','interrupted') or not row.get('report_ref'):
            raise DispatchError('unsettled Claude attempts cannot migrate')
        if row['task_id'] not in tasks:
            raise DispatchError('orphan Claude task reference')
    for table in ('control_task_rules','control_reservations','control_approvals','host_attempts','host_events'):
        if any(r['task_id'] not in tasks for r in records.get(table, [])):
            raise DispatchError('orphan task reference in '+table)


def portable(records, *, include_fixed_refs=True):
    blocked = [task["task_id"] for task in records["tasks"]
               if task["access"] == "local_only" or
               (task["access"] == "exportable" and task["egress"] == "none")]
    blocked.extend(item["task_id"] for item in records["evidence"] if item["access"] == "local_only")
    if blocked:
        raise ArtifactError("E_EXPORT_BLOCKED", "restricted tasks: " + ", ".join(sorted(set(blocked))))
    if any(row["class"] == "local_only" for row in records.get("unified_events", [])):
        raise ArtifactError("E_EXPORT_BLOCKED", "local_only projection events cannot leave this host")
    try:
        _settled(records)
    except DispatchError as exc:
        raise ArtifactError("E_EXPORT_BLOCKED", str(exc)) from exc
    if records["late_results"]:
        raise ArtifactError("E_EXPORT_BLOCKED", "bundles with late receipts require local review")
    hashes = {item["artifact_hash"] for item in records["evidence"] if item["artifact_hash"]}
    for table, field in (("reconciliations", "evidence_ref"), ("component_capabilities", "proof_ref"),
                         ("transport_artifact_grants", "content_hash"),
                         ('control_approvals','evidence_ref'), ('control_reservations','evidence_ref'),
                         ('control_handoffs','authorization_ref'), ('control_handoffs','receipt_ref'),
                         ('host_attempts','prompt_ref'), ('host_attempts','report_ref'), ('host_events','event_ref'),
                         ('claude_attempts','prompt_ref'), ('claude_attempts','report_ref')):
        hashes.update(row[field] for row in records.get(table, []) if row.get(field))
    for table,field in (('control_handoffs','scope_refs_json'),('control_handoffs','evidence_refs_json'),
                       ('control_events','refs_json')):
        for row in records.get(table, []):
            refs=json.loads(row[field])
            if not isinstance(refs,list) or any(not isinstance(r,str) for r in refs):
                raise ArtifactError('E_EXPORT_BLOCKED','invalid control evidence references')
            hashes.update(refs)
    if include_fixed_refs:
        for row in records['tasks']:
            for ref in json.loads(row['input_refs_json']):
                hashes.add(ref['hash'])
        for row in records.get('unified_events',[]):
            for ref in json.loads(row['refs_json']):
                match=re.search(r'#(?:sha256:)?([0-9a-f]{64})$',ref)
                if not match:raise ArtifactError('E_EXPORT_BLOCKED','unparseable fixed projection reference')
                hashes.add('sha256:'+match.group(1))
    return sorted(hashes)


def _artifact_inventory(records, store, *, legacy=False):
    hashes = set(portable(records,include_fixed_refs=not legacy))
    # Only this known schema owns these four child artifacts. Do not recursively
    # scrape arbitrary hashes from component payloads or user-controlled text.
    proof_fields = ("first_result_hash", "second_result_hash",
                    "state_after_first_ref", "state_after_second_ref")
    for capability in records.get("component_capabilities", []):
        ref = capability.get("proof_ref")
        if not ref:
            continue
        try:
            proof = json.loads(store.get(ref))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            if capability["idempotency_proof"] == "verified":
                raise ArtifactError("E_BUNDLE_INVALID", "verified proof is not readable JSON") from exc
            continue
        if isinstance(proof, dict) and proof.get("schema") == "sa_dispatch.idempotency_proof.v1":
            for field in proof_fields:
                if proof.get(field):
                    store.get(proof[field])
                    hashes.add(proof[field])
    if not legacy:
        for attempt in records.get('claude_attempts',[]):
            proof=json.loads(store.get(attempt['report_ref']))
            if (not isinstance(proof,dict) or proof.get('schema')!='sa_dispatch.claude_report.v1' or
                any(proof.get(key)!=attempt[key] for key in ('task_id','fence','session_id','model','prompt_ref')) or
                proof.get('status')!=attempt['phase']):
                raise ArtifactError('E_BUNDLE_INVALID','Claude result ownership mismatch')
            if attempt['phase']=='interrupted' and (type(proof.get('exit_code')) is not int or
                    proof.get('error') not in ('CLAUDE_TIMEOUT','CLAUDE_OUTPUT_LIMIT')):
                raise ArtifactError('E_BUNDLE_INVALID','interrupted Claude attempt needs confirmed process exit')
            if not isinstance(proof.get('stdout_ref'),str) or not re.fullmatch('sha256:[0-9a-f]{64}',proof['stdout_ref']):
                raise ArtifactError('E_BUNDLE_INVALID','Claude raw output reference is required')
            if attempt['phase']=='succeeded':
                init_ref=proof.get('init_ref')
                if not isinstance(init_ref,str) or not re.fullmatch('sha256:[0-9a-f]{64}',init_ref):
                    raise ArtifactError('E_BUNDLE_INVALID','successful Claude attempt needs isolation evidence')
                init=json.loads(store.get(init_ref))
                if (not isinstance(init,dict) or init.get('type')!='system' or init.get('subtype')!='init' or
                    init.get('tools')!=[] or init.get('mcp_servers')!=[] or
                    init.get('model')!=attempt['model'] or init.get('session_id')!=attempt['session_id']):
                    raise ArtifactError('E_BUNDLE_INVALID','Claude isolation evidence does not match')
            for field in ('prompt_ref','stdout_ref','init_ref'):
                if proof.get(field):
                    store.get(proof[field]);hashes.add(proof[field])
        for reservation in records.get('control_reservations',[]):
            ref=reservation.get('evidence_ref')
            if not ref:continue
            proof=json.loads(store.get(ref))
            if isinstance(proof,dict) and proof.get('schema')=='sa_dispatch.host_run_usage.v1':
                child=proof['terminal_event_ref'];store.get(child);hashes.add(child)
    return sorted(hashes)


def _normalize_snapshot(records):
    if not isinstance(records, dict):
        raise DispatchError("invalid snapshot tables")
    supplied = set(records)
    legacy = set(V1_TABLES) | {"devices"}
    if supplied not in (set(SNAPSHOT_TABLES), set(TABLES), set(V3_TABLES),set(V3_TABLES)|{'devices'},set(V2_TABLES), set(V2_TABLES)|{'devices'}, legacy, set(V1_TABLES)):
        raise DispatchError("invalid snapshot tables")
    result = {name: records.get(name, []) for name in SNAPSHOT_TABLES}
    if any(not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows)
           for rows in result.values()):
        raise DispatchError("invalid snapshot records")
    return result


def import_snapshot_records(conn, records):
    """Use inside store._tx(); restore all rows, force schedules.enabled=0.

    No commit or external call occurs here. Source enabled states stay in the
    hashed bundle and intentional runtime changes are reported to the caller.
    """
    records = _normalize_snapshot(records)
    _settled(records)
    present = _present(conn)
    content_tables = set(SNAPSHOT_TABLES) - {"schema_migrations"}
    if _unknown_populated(conn) or any(conn.execute("SELECT 1 FROM " + name + " LIMIT 1").fetchone()
                                     for name in present & content_tables):
        raise DispatchError("import requires empty store, including extension tables")
    if records["schedules"] or records["schedule_firings"] or records["schedule_events"]:
        from .scheduler import initialize_schema
        initialize_schema(conn)
    if records["unified_events"]:
        from .unified_events import initialize_schema
        initialize_schema(conn)
    migration_preserved = not bool(records["schema_migrations"])
    if records["schema_migrations"]:
        if "schema_migrations" not in present:
            raise DispatchError("target must initialize source schema migrations before import")
        target = {r["version"]: r["name"] for r in conn.execute("SELECT * FROM schema_migrations")}
        source = {r["version"]: r["name"] for r in records["schema_migrations"]}
        if any(target.get(version) != name for version,name in source.items()):
            raise DispatchError("source and target schema migrations disagree")
        migration_preserved = bool(set(target)-set(source))
        for version in source:
            conn.execute('DELETE FROM schema_migrations WHERE version=?',(version,))
    conn.execute("PRAGMA defer_foreign_keys=ON")
    disabled = []
    for table in SNAPSHOT_TABLES:
        info = list(conn.execute("PRAGMA table_info(" + table + ")"))
        columns = {row["name"] for row in info}
        required = {row["name"] for row in info if (row["notnull"] and row["dflt_value"] is None) or row["pk"]}
        for original in records[table]:
            row = dict(original)
            if not set(row) <= columns or not required <= set(row):
                raise DispatchError("invalid snapshot columns for " + table)
            if table == "schedules":
                if row["enabled"]:
                    disabled.append(row["id"])
                row["enabled"] = 0
            if table == 'claude_attempts':
                # Imported session identifiers are audit metadata, never execution rights.
                row['run_dir']=''
                row['execution_authority']='historical_only'
            try:
                conn.execute("INSERT INTO " + table + "(" + ",".join(row) + ") VALUES(" +
                             ",".join("?" for _ in row) + ")", tuple(row.values()))
            except sqlite3.IntegrityError as exc:
                raise DispatchError("invalid snapshot rows for " + table) from exc
    if conn.execute("PRAGMA foreign_key_check").fetchone():
        raise DispatchError("invalid snapshot references")
    return {"disabled_schedule_ids": sorted(disabled), "schedules_enabled": 0,
            "target_migration_metadata_retained": migration_preserved,
            "rows": {name: len(rows) for name, rows in records.items()}}


def export_bundle(config, destination):
    path = Path(destination).resolve()
    if path.exists():
        raise ArtifactError("E_BUNDLE_EXISTS", "choose a new bundle directory")
    records = ledger(config.db_path)
    # Direct API callers may export an unopened pre-0010 ledger. Normalize only
    # the portable records; never mutate the source database during export.
    for schedule in records.get('schedules', []):
        schedule.setdefault('max_slots', None)
    source = ArtifactStore(config.artifact_root)
    hashes = _artifact_inventory(records, source)
    for attempt in records.get('claude_attempts',[]):
        attempt['run_dir']=''
        attempt['execution_authority']='historical_only'
    with tempfile.TemporaryDirectory(prefix=".dispatch-", dir=path.parent) as work:
        staging = Path(work) / "bundle"
        staging.mkdir()
        target = ArtifactStore(staging / "artifacts")
        files = {}
        for table, items in records.items():
            name = table + ".jsonl"
            content = b"".join(receipt_bytes(item) + b"\n" for item in items)
            (staging / name).write_bytes(content)
            files[name] = sha256_ref(content)
        for ref in hashes:
            target.put(source.get(ref))
        manifest = {"schema": FORMAT, "files": files, "artifacts": hashes,
                    "import_policy": {"schedules": "disabled", "devices": "excluded"},
                    "source_counts": {name: len(rows) for name, rows in records.items()}}
        (staging / "manifest.json").write_bytes(receipt_bytes(manifest))
        staging.rename(path)
    return manifest


def read_bundle(path):
    path = Path(path).resolve()
    try:
        manifest_path = path / "manifest.json"
        if not manifest_path.resolve().is_relative_to(path):
            raise ValueError("manifest location escapes the bundle")
        manifest = json.loads(manifest_path.read_bytes())
        if manifest["schema"] not in (V1_FORMAT, V2_FORMAT,V3_FORMAT,V4_FORMAT, FORMAT):
            raise ValueError("unsupported bundle format")
        layout = {V1_FORMAT:V1_TABLES,V2_FORMAT:V2_TABLES,V3_FORMAT:V3_TABLES,V4_FORMAT:V4_TABLES,FORMAT:TABLES}[manifest['schema']]
        expected = {name + ".jsonl" for name in layout}
        if set(manifest["files"]) != expected or {p.name for p in path.glob("*.jsonl")} != expected:
            raise ValueError("unsupported bundle layout")
        records = {table: [] for table in TABLES}
        for table in layout:
            name = table + ".jsonl"
            file = path / name
            if not file.resolve().is_relative_to(path):
                raise ValueError("record location escapes the bundle")
            content = file.read_bytes()
            if sha256_ref(content) != manifest["files"][name]:
                raise ArtifactError("E_HASH_MISMATCH", "bundle record hash mismatch")
            records[table] = [json.loads(line) for line in content.splitlines()]
            if any(not isinstance(row, dict) for row in records[table]):
                raise ValueError("record must be an object")
        for schedule in records.get('schedules',[]):
            if ('max_slots' in schedule)!=(manifest['schema']==FORMAT):
                raise ValueError('schedule columns do not match the declared bundle version')
        if manifest["schema"] in (V2_FORMAT,V3_FORMAT,V4_FORMAT,FORMAT):
            if manifest.get("import_policy") != {"schedules": "disabled", "devices": "excluded"}:
                raise ValueError("unsupported import policy")
            if manifest.get("source_counts") != {name: len(records[name]) for name in layout}:
                raise ValueError("record counts disagree")
        store = ArtifactStore(path / "artifacts")
        if not store.root.is_relative_to(path):
            raise ValueError("artifact root escapes the bundle")
        if _artifact_inventory(records, store,legacy=manifest['schema'] in (V1_FORMAT,V2_FORMAT)) != manifest["artifacts"]:
            raise ValueError("unexpected artifact inventory")
        blobs = {ref: store.get(ref) for ref in manifest["artifacts"]}
        return manifest, records, blobs
    except ArtifactError:
        raise
    except (KeyError, TypeError, OSError, ValueError, DispatchError) as exc:
        raise ArtifactError("E_BUNDLE_INVALID", "bundle cannot be read") from exc


def verify_bundle(path):
    manifest, records, _ = read_bundle(path)
    return {"tasks": len(records["tasks"]), "artifacts": len(manifest["artifacts"]),
            "schema": manifest["schema"], "rows": {name: len(rows) for name, rows in records.items()}}


def import_bundle(config, path, store):
    manifest, records, blobs = read_bundle(path)
    target = ArtifactStore(config.artifact_root)
    # Immutable staging may leave unreferenced blobs on rejection, never partial ledger rows.
    for blob in blobs.values():
        target.put(blob)
    with store._tx() as conn:
        report = import_snapshot_records(conn, {**records, "devices": []})
    return {"tasks": len(records["tasks"]), "artifacts": len(manifest["artifacts"]),
            "schema": manifest["schema"], **report}
